package com.aduana.aduana.login;

import lombok.Data;

@Data
public class LoginDTO {
    private String rut;
    private String password;
}
